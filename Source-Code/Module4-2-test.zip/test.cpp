// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
  ~Environment() override {}

  // Override this to define how to set up the environment.
  void SetUp() override
  {
    //  initialize random seed
    srand(time(nullptr));
  }

  // Override this to define how to tear down the environment.
  void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
  // create a smart point to hold our collection
  std::unique_ptr<std::vector<int>> collection;

  void SetUp() override
  { // create a new collection to be used in the test
    collection.reset(new std::vector<int>);
  }

  void TearDown() override
  { //  erase all elements in the collection, if any remain
    collection->clear();
    // free the pointer
    collection.reset(nullptr);
  }

  // helper function to add random values from 0 to 99 count times to the collection
  void add_entries(int count)
  {
    assert(count > 0);
    for (auto i = 0; i < count; ++i)
      collection->push_back(rand() % 100);
  }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
  // is the collection created
  ASSERT_TRUE(collection);

  // if empty, the size must be 0
  ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
  // is the collection empty?
  ASSERT_TRUE(collection->empty());

  // if empty, the size must be 0
  ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
/*
TEST_F(CollectionTest, AlwaysFail)
{
  FAIL();
}
*/

// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
  // is the collection empty?
  ASSERT_TRUE(collection->empty());

  // if empty, the size must be 0
  ASSERT_EQ(collection->size(), 0);

  add_entries(1);

  // is the collection still empty?
  ASSERT_FALSE(collection->empty());

  // if not empty, what must the size be?
  ASSERT_EQ(collection->size(), 1);
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
  // [TMA] SetUp() is called before every test using the fixture,
  // which initializes the collection, so we know the initial size
  // is 0. However, capturing the size before the addition more
  // directly tests that adding five entries increases the size by
  // five and helps future-proof the test.
  auto n = collection->size();

  add_entries(5);

  ASSERT_EQ(collection->size(), n + 5);
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CompareMaxSizeAgainstSize)
{
  // size() = 0
  EXPECT_TRUE(collection->max_size() >= collection->size());

  add_entries(1);
  // size() = 1
  EXPECT_TRUE(collection->max_size() >= collection->size());

  add_entries(4);
  // size() = 5
  EXPECT_TRUE(collection->max_size() >= collection->size());

  add_entries(5);
  // size() = 10
  EXPECT_TRUE(collection->max_size() >= collection->size());
}

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CompareCapacityAgainstSize)
{
  // size() = 0
  EXPECT_TRUE(collection->capacity() >= collection->size());

  add_entries(1);
  // size() = 1
  EXPECT_TRUE(collection->capacity() >= collection->size());

  add_entries(4);
  // size() = 5
  EXPECT_TRUE(collection->capacity() >= collection->size());

  add_entries(5);
  // size() = 10
  EXPECT_TRUE(collection->capacity() >= collection->size());
}

// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, VerifyResizeIncreasesSize)
{
  // Get the size. Should be 0
  auto n = collection->size();

  // Resize the collection to n + 1. Should be 1.
  collection->resize(n + 1);

  // Verify the collection size increased by one.
  EXPECT_EQ(collection->size(), n + 1);
}

// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, VerifyResizeDecreasesSize)
{
  // Add 2 entries to empty collection.
  add_entries(2);

  // Verify collection size is 2
  ASSERT_EQ(collection->size(), 2);

  // Resize collection to 1
  collection->resize(1);

  // Verify collection size is 1
  EXPECT_EQ(collection->size(), 1);
}

// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, VerifyResizeDecreasesSizeToZero)
{
  // Add 1 entry to empty collection.
  add_entries(1);

  // Verify collection size is 1
  ASSERT_EQ(collection->size(), 1);

  // Resize the collection to 0
  collection->resize(0);

  // Verify collection size is 0
  EXPECT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest, VerifyClearErasesAllEntries)
{
  // Add 1 entry to empty collection.
  add_entries(1);

  // Verify collection size is 1
  ASSERT_EQ(collection->size(), 1);

  // Clear the collection.
  collection->clear();

  // Verify collection size is 0
  EXPECT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, VerifyEraseRangeErasesCollection)
{
  // Add 5 entries to empty collection.
  add_entries(5);

  // Verify collection size is 5
  ASSERT_EQ(collection->size(), 5);

  // Erase all entries from collection.
  collection->erase(collection->begin(), collection->end());

  // Verify collection size is 0
  EXPECT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, VerifyReserveIncreasesCapacityNotSize)
{
  // Get current collection capacity.
  auto capacity = collection->capacity();

  // Get current collection size. Should be 0
  auto n = collection->size();

  // Reserve memory for 5 entries.
  collection->reserve(5);

  // Verify the current collection capacity is greater than the original 
  // collection capacity.
  EXPECT_GT(collection->capacity(), capacity);

  // Verify the current collection size is equal to the original 
  // collection size.
  EXPECT_EQ(collection->size(), n);
}

// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, VerifyOutOfRangeExceptionThrown)
{
  // Verify that specifying an invalid index for the at() function causes a std::out_of_range
  // exception to be thrown.
  EXPECT_THROW(static_cast<void>(collection->at(collection->size())), std::out_of_range);
}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative

// [TMA] Call push_back() to increase size() and verify the new value is accessible 
// with back().
TEST_F(CollectionTest, VerifyPushBackWithBack)
{
  // Add an entry to the empty collection with a value of 42. 
  collection->push_back(42);

  // Verify collection size is 1
  ASSERT_EQ(collection->size(), 1);

  // Get the most recently added entry and verify that its value is 42. 
  EXPECT_EQ(collection->back(), 42);
}

// [TMA] Negative test to verify that adding one entry does not result
// in an incorrect collection size.
TEST_F(CollectionTest, VerifyCollectionSizeIsNotTwo)
{
  // Add one entry to the empty collection.
  add_entries(1);

  // Verify that the collection does not incorrectly report a size of 2.
  EXPECT_FALSE(collection->size() == 2);
}
