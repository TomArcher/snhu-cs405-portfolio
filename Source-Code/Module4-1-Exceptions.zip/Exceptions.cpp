// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

// [TMA] Include all necessary standard headers instead of including only iostream and 
// expecting it to transitively include everything needed.
#include <iostream>
#include <exception>
#include <string>
#include <stdexcept>

// [TMA]  Define a custom exception class derived from std::exception.
class MyException : public std::exception
{
public:
  explicit MyException(const char* message)
    : msg_(message) {
  }

  explicit MyException(const std::string& message)
    : msg_(message) {
  }

  ~MyException() noexcept override = default;

  const char* what() const noexcept override {
    return msg_.c_str();
  }

protected:
  std::string msg_;
};

bool do_even_more_custom_application_logic()
{
  // [TMA] Throw a standard exception to test the caller's exception handler.
  throw std::logic_error("Test logic error exception");

  std::cout << "Running Even More Custom Application Logic." << std::endl;

  return true;
}

void do_custom_application_logic()
{
  // [TMA] Wrap the call to do_even_more_custom_application_logic()
  // with an exception handler that catches std::exception (and derived 
  // classes). In the catch block, display a message and the result from 
  // the exception's what() member function, then continue processing.
  try
  {
    std::cout << "Running Custom Application Logic." << std::endl;

    if (do_even_more_custom_application_logic())
    {
      std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
    }
  }
  catch (const std::exception& ex)
  {
    std::cout << "Standard exception caught: " << ex.what() << std::endl;
  }

  // [TMA] Throw the custom MyException to test the exception handler in the 
  // main() function.
  throw MyException("This is a custom exception");

  std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
  // [TMA] Because C++ does not have an explicit "divide by zero" exception,
  // the standard portable technique is to test the denominator value,  
  // and if zero, throw a std::domain_error exception, supplying a text value 
  // in the exception's c'tor indicating that the exception is the result of a 
  // division-by-zero error.
  if (den == 0) throw std::domain_error("Division by zero");
  return num / den;
}

void do_division() noexcept
{
  float numerator = 10.0f;
  float denominator = 0;

  // [TMA] Exception handler to capture ONLY the exception thrown
  // by the divide() function as a result of the denominator being zero.
  try
  {
    auto result = divide(numerator, denominator);
    std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
  }
  catch (const std::domain_error& ex)
  {
    std::cout << "Domain error exception caught: " << ex.what() << std::endl;
  }
}

int main()
{
  std::cout << "Exceptions Tests!" << std::endl;

  // [TMA] Exception handlers that catch the following exceptions, in order,
  // and print the exception type, along with the result of calling
  // the exception's what() member function.
  // 
  // MyException (custom exception)
  // std::exception (polymorphically catches std::exception and derived exceptions)
  // "catch all" handler (to catch any uncaught exceptions)
  try 
  {
    do_division();
    do_custom_application_logic();
  }
  catch (const MyException& ex)
  {
    std::cout << "MyException caught: " << ex.what() << std::endl;
  }
  catch (const std::exception& ex)
  {
    std::cout << "std::exception caught: " << ex.what() << std::endl;
  }
  catch (...)
  {
    std::cout << "Unknown exception caught" << std::endl;
  }

  return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
